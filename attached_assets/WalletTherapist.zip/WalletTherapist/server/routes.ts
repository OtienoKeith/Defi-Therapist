import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import OpenAI from "openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create OpenAI client
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY || '',
  });

  // Analyze trading activity endpoint
  app.post('/api/analyze', async (req, res) => {
    try {
      const { address, trades } = req.body;
      
      if (!address || !trades || !Array.isArray(trades) || trades.length === 0) {
        return res.status(400).json({ message: 'Invalid request. Wallet address and trades are required.' });
      }
      
      // Format trades into a readable summary
      const formatTrades = (trades: any[]) => {
        let profitableTrades = trades.filter(t => t.profit > 0);
        let losingTrades = trades.filter(t => t.profit < 0);
        
        let totalProfit = trades.reduce((sum, trade) => sum + trade.profit, 0);
        let largestGain = Math.max(...trades.map(t => t.profit));
        let largestLoss = Math.min(...trades.map(t => t.profit));
        
        return `
          Based on the wallet ${address}, there have been ${trades.length} trades in the recent period.
          - ${profitableTrades.length} profitable trades
          - ${losingTrades.length} losing trades
          - Total profit/loss: ${totalProfit.toFixed(2)} SOL
          - Largest gain: ${largestGain.toFixed(2)} SOL
          - Largest loss: ${largestLoss.toFixed(2)} SOL
          
          Trade details:
          ${trades.map(t => 
            `- ${t.pair}: Bought at ${t.buyPrice} USDC, Sold at ${t.sellPrice} USDC, Profit: ${t.profit.toFixed(2)} SOL`
          ).join('\n')}
        `;
      };
      
      // Send to OpenAI for analysis
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are a professional trading psychologist specializing in cryptocurrency trading. 
            Analyze the trading data provided and give insightful feedback on the trader's psychology, habits, and patterns.
            Focus on emotional biases, risk management, and strategy consistency.
            Respond with a JSON object that includes:
            1. "summary": A brief summary of the trading activity
            2. "analysis": An array of 2-3 paragraphs with your psychological analysis
            3. "recommendations": An array of 3-5 specific recommendations to improve
            4. "strengths": An array of 2-3 strengths in the trading behavior
            5. "improvements": An array of 2-3 areas for improvement`,
          },
          {
            role: "user",
            content: formatTrades(trades),
          },
        ],
        response_format: { type: "json_object" },
      });
      
      // Parse and validate the response
      const content = response.choices[0].message.content;
      const analysisResult = JSON.parse(content !== null ? content : '{}');
      
      // Store the analysis in the database
      await storage.saveTradeAnalysis({
        walletAddress: address,
        tradingSummary: analysisResult.summary,
        analysisText: analysisResult.analysis.join('\n\n'),
        recommendations: analysisResult.recommendations,
        strengths: analysisResult.strengths,
        areasForImprovement: analysisResult.improvements,
      });
      
      // Return the analysis to the client
      return res.status(200).json(analysisResult);
      
    } catch (error: any) {
      console.error('Analysis error:', error);
      
      if (error.name === 'OpenAIError') {
        return res.status(500).json({ message: 'Error communicating with AI service: ' + error.message });
      }
      
      return res.status(500).json({ message: 'Error analyzing trades: ' + error.message });
    }
  });

  // Get previous analyses for a wallet address
  app.get('/api/analyses/:address', async (req, res) => {
    try {
      const { address } = req.params;
      
      if (!address) {
        return res.status(400).json({ message: 'Wallet address is required' });
      }
      
      const analyses = await storage.getTradeAnalysesForWallet(address);
      return res.status(200).json(analyses);
      
    } catch (error: any) {
      console.error('Error fetching analyses:', error);
      return res.status(500).json({ message: 'Error fetching analyses: ' + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
