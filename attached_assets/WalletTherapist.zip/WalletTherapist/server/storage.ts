import { 
  users, 
  type User, 
  type InsertUser, 
  type TradeAnalysis, 
  type InsertTradeAnalysis 
} from "@shared/schema";

// Extend the interface with trade analysis methods
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Trade analysis methods
  saveTradeAnalysis(analysis: InsertTradeAnalysis): Promise<TradeAnalysis>;
  getTradeAnalysisById(id: number): Promise<TradeAnalysis | undefined>;
  getTradeAnalysesForWallet(walletAddress: string): Promise<TradeAnalysis[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tradeAnalyses: Map<number, TradeAnalysis>;
  currentUserId: number;
  currentAnalysisId: number;

  constructor() {
    this.users = new Map();
    this.tradeAnalyses = new Map();
    this.currentUserId = 1;
    this.currentAnalysisId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Trade analysis methods
  async saveTradeAnalysis(analysisData: InsertTradeAnalysis): Promise<TradeAnalysis> {
    const id = this.currentAnalysisId++;
    const now = new Date();
    
    const analysis: TradeAnalysis = {
      ...analysisData,
      id,
      analysisDate: now,
    };
    
    this.tradeAnalyses.set(id, analysis);
    return analysis;
  }

  async getTradeAnalysisById(id: number): Promise<TradeAnalysis | undefined> {
    return this.tradeAnalyses.get(id);
  }

  async getTradeAnalysesForWallet(walletAddress: string): Promise<TradeAnalysis[]> {
    return Array.from(this.tradeAnalyses.values())
      .filter(analysis => analysis.walletAddress === walletAddress)
      .sort((a, b) => b.analysisDate.getTime() - a.analysisDate.getTime()); // Sort by date, newest first
  }
}

export const storage = new MemStorage();
