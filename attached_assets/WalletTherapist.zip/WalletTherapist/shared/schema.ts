import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema remains the same from the original file
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// New schema for trade analysis
export const tradeAnalysis = pgTable("trade_analysis", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull(),
  analysisDate: timestamp("analysis_date").defaultNow().notNull(),
  tradingSummary: text("trading_summary").notNull(),
  analysisText: text("analysis_text").notNull(),
  recommendations: jsonb("recommendations").notNull(),
  strengths: jsonb("strengths").notNull(),
  areasForImprovement: jsonb("areas_for_improvement").notNull(),
});

export const insertTradeAnalysisSchema = createInsertSchema(tradeAnalysis).omit({
  id: true,
  analysisDate: true,
});

// Schema for trade history
export const tradeHistory = pgTable("trade_history", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull(),
  pair: text("pair").notNull(),
  buyPrice: integer("buy_price").notNull(),
  sellPrice: integer("sell_price").notNull(),
  amount: integer("amount").notNull(),
  profit: integer("profit").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertTradeHistorySchema = createInsertSchema(tradeHistory).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTradeAnalysis = z.infer<typeof insertTradeAnalysisSchema>;
export type TradeAnalysis = typeof tradeAnalysis.$inferSelect;

export type InsertTradeHistory = z.infer<typeof insertTradeHistorySchema>;
export type TradeHistory = typeof tradeHistory.$inferSelect;
