import { useState, useEffect } from "react";
import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import WalletInfo from "@/components/wallet-info";
import RecentTrades from "@/components/recent-trades";
import ResultsSection from "@/components/results-section";
import { connectWallet, disconnectWallet, getWalletInfo } from "@/lib/phantom";
import { getTrades } from "@/lib/okx";
import { WalletInfo as WalletInfoType, TradeData } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [walletConnected, setWalletConnected] = useState(false);
  const [walletInfo, setWalletInfo] = useState<WalletInfoType | null>(null);
  const [trades, setTrades] = useState<TradeData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Check if there's an existing wallet connection
    const checkWalletConnection = async () => {
      const isConnected = await connectWallet(true);
      if (isConnected) {
        setWalletConnected(true);
        fetchWalletInfo();
      }
    };

    checkWalletConnection();
  }, []);

  const fetchWalletInfo = async () => {
    try {
      const info = await getWalletInfo();
      setWalletInfo(info);
    } catch (error) {
      console.error("Error fetching wallet info:", error);
      toast({
        title: "Error",
        description: "Failed to get wallet information. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleConnectWallet = async () => {
    setIsLoading(true);
    try {
      const connected = await connectWallet();
      if (connected) {
        setWalletConnected(true);
        fetchWalletInfo();
        fetchTrades();
        toast({
          title: "Success",
          description: "Wallet connected successfully!",
        });
      }
    } catch (error) {
      console.error("Error connecting wallet:", error);
      toast({
        title: "Connection Error",
        description: "Could not connect to Phantom wallet. Please make sure it's installed and try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDisconnectWallet = async () => {
    try {
      await disconnectWallet();
      setWalletConnected(false);
      setWalletInfo(null);
      setTrades([]);
      setAnalysisResult(null);
      toast({
        title: "Disconnected",
        description: "Wallet has been disconnected.",
      });
    } catch (error) {
      console.error("Error disconnecting wallet:", error);
      toast({
        title: "Error",
        description: "Failed to disconnect wallet. Please try again.",
        variant: "destructive",
      });
    }
  };

  const fetchTrades = async () => {
    if (!walletInfo?.address) return;
    
    try {
      console.log("Fetching trades for wallet:", walletInfo.address);
      const tradeData = await getTrades(walletInfo.address);
      console.log("Fetched trades:", tradeData);
      setTrades(tradeData);
      
      // Show success toast with trade count
      toast({
        title: "Trades Loaded",
        description: `Retrieved ${tradeData.length} recent trades.`,
      });
    } catch (error) {
      console.error("Error fetching trades:", error);
      toast({
        title: "Error",
        description: "Failed to fetch trading activity. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleAnalyzeTrades = async () => {
    if (!walletInfo?.address || trades.length === 0) {
      toast({
        title: "No Data",
        description: "No trading data available to analyze. Please connect your wallet and ensure you have trading history.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    
    try {
      console.log("Sending trade data for analysis:", { address: walletInfo.address, tradeCount: trades.length });
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          address: walletInfo.address,
          trades
        }),
      });
      
      if (!response.ok) {
        console.error("API error status:", response.status);
        console.error("API error statusText:", response.statusText);
        const errorText = await response.text().catch(() => "Unknown error");
        console.error("API error details:", errorText);
        throw new Error(`Analysis failed: ${response.status} ${response.statusText}`);
      }
      
      const result = await response.json();
      console.log("Analysis result received:", result);
      setAnalysisResult(result);
      
      toast({
        title: "Analysis Complete",
        description: "Your trading psychology analysis is ready!",
      });
    } catch (err: any) {
      console.error("Analysis error:", err);
      setError(err.message || "Failed to analyze trades. Please try again.");
      toast({
        title: "Analysis Failed",
        description: err.message || "Something went wrong analyzing your trades. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleRetry = () => {
    setError(null);
    handleAnalyzeTrades();
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <Header walletConnected={walletConnected} walletAddress={walletInfo?.address} />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <HeroSection />
          
          <div className="grid md:grid-cols-12 gap-8">
            <div className="md:col-span-7 lg:col-span-8 flex flex-col">
              {/* Featured Image + Connection & Analysis Section */}
              <div className="rounded-xl overflow-hidden shadow-md mb-6 aspect-[16/9] relative">
                <img 
                  src="https://images.unsplash.com/photo-1559526324-593bc073d938?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" 
                  alt="Trading data visualization concept" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/70 to-transparent flex items-end">
                  <div className="p-6">
                    <h3 className="text-white text-xl font-semibold">AI-Powered Trading Psychology Analysis</h3>
                    <p className="text-white/80 text-sm mt-2">Get insights into your trading patterns and emotional responses</p>
                  </div>
                </div>
              </div>
              
              <Card className="p-6 mb-6 border-2 border-primary/40 bg-card shadow-xl">
                <h3 className="text-2xl font-semibold mb-4 text-card-foreground">Connect & Analyze</h3>
                <p className="text-muted-foreground text-lg mb-6">
                  First, connect your Phantom wallet to access your trading history. Then, request your personalized trading therapy session.
                </p>
                
                <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                  {!walletConnected ? (
                    <Button 
                      className="flex-1 flex items-center justify-center text-lg py-6"
                      onClick={handleConnectWallet}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <span className="flex items-center">
                          <i className="fas fa-circle-notch fa-spin mr-2"></i>
                          Connecting...
                        </span>
                      ) : (
                        <span className="flex items-center">
                          <img 
                            src="/src/assets/phantom-logo.png" 
                            alt="Phantom Logo" 
                            className="w-6 h-6 mr-2" 
                          />
                          Connect Phantom Wallet
                        </span>
                      )}
                    </Button>
                  ) : (
                    <Button 
                      variant="outline" 
                      className="flex-1 flex items-center justify-center"
                      onClick={handleDisconnectWallet}
                    >
                      <i className="fas fa-unlink mr-2"></i>
                      Disconnect Wallet
                    </Button>
                  )}
                  
                  <Button 
                    className="flex-1 flex items-center justify-center text-lg py-6"
                    onClick={handleAnalyzeTrades}
                    disabled={!walletConnected || isAnalyzing}
                    variant="secondary"
                  >
                    {isAnalyzing ? (
                      <span className="flex items-center">
                        <i className="fas fa-circle-notch fa-spin mr-2 text-xl"></i>
                        Analyzing Trading Data...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <i className="fas fa-brain mr-2 text-xl"></i>
                        Get Trade Therapy Analysis
                      </span>
                    )}
                  </Button>
                </div>
              </Card>
              
              {/* Results Section */}
              {(isAnalyzing || analysisResult || error) && (
                <ResultsSection 
                  isAnalyzing={isAnalyzing} 
                  analysisResult={analysisResult} 
                  error={error}
                  onRetry={handleRetry}
                />
              )}
            </div>
            
            <div className="md:col-span-5 lg:col-span-4 space-y-6">
              <WalletInfo 
                walletConnected={walletConnected} 
                walletInfo={walletInfo}
                onConnect={handleConnectWallet}
                onDisconnect={handleDisconnectWallet}
                isLoading={isLoading}
              />
              
              <RecentTrades 
                walletConnected={walletConnected} 
                trades={trades} 
              />
              
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
