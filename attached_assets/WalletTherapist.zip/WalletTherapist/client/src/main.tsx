import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Set title
document.title = "DeFi Therapist | Trading Psychology Analysis";

// Add meta description for SEO
const metaDescription = document.createElement('meta');
metaDescription.name = 'description';
metaDescription.content = 'Connect your Phantom wallet for AI-powered analysis of your Solana trading psychology and get personalized recommendations to improve your trading strategy.';
document.head.appendChild(metaDescription);

// Add font
const fontLink = document.createElement('link');
fontLink.rel = 'stylesheet';
fontLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
document.head.appendChild(fontLink);

// Add font awesome
const faLink = document.createElement('link');
faLink.rel = 'stylesheet';
faLink.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css';
document.head.appendChild(faLink);

// Set dark mode
document.documentElement.classList.add('dark');

createRoot(document.getElementById("root")!).render(<App />);
