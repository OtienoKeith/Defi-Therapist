import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const AboutSection: React.FC = () => {
  return (
    <Card className="shadow-md">
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-4">About DeFi Therapist</h3>
        <p className="text-gray-600 text-sm mb-4">
          DeFi Therapist uses advanced AI to analyze your trading patterns and provide personalized insights to improve your trading psychology and performance.
        </p>
        
        <img 
          src="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
          alt="Blockchain trading concept visualization" 
          className="w-full h-auto rounded-lg mb-4"
        />
        
        <div className="flex space-x-3 text-sm">
          <a href="#" className="text-primary hover:text-primary-dark">How it Works</a>
          <a href="#" className="text-primary hover:text-primary-dark">Privacy Policy</a>
          <a href="#" className="text-primary hover:text-primary-dark">FAQs</a>
        </div>
      </CardContent>
    </Card>
  );
};

export default AboutSection;
