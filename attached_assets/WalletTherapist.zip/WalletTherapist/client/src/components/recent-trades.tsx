import React from "react";
import { formatDistanceToNow } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TradeData } from "@/lib/types";

interface RecentTradesProps {
  walletConnected: boolean;
  trades: TradeData[];
}

const RecentTrades: React.FC<RecentTradesProps> = ({
  walletConnected,
  trades,
}) => {
  return (
    <Card className="shadow-md">
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-4">Recent Trading Activity</h3>
        
        {!walletConnected ? (
          <div className="py-8 text-center">
            <div className="inline-flex items-center justify-center h-20 w-20 rounded-full bg-secondary/20 mb-4">
              <i className="fas fa-chart-line text-3xl text-secondary"></i>
            </div>
            <p className="text-lg text-muted-foreground">Connect your wallet to view recent trades</p>
          </div>
        ) : (
          <div>
            {trades.length === 0 ? (
              <div className="py-8 text-center">
                <div className="inline-flex items-center justify-center h-20 w-20 rounded-full bg-secondary/20 mb-4">
                  <i className="fas fa-chart-line text-3xl text-secondary"></i>
                </div>
                <p className="text-lg text-muted-foreground">No trading activity found for your wallet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {trades.slice(0, 3).map((trade, index) => (
                  <div key={index} className="border-b pb-3">
                    <div className="flex justify-between items-start mb-1">
                      <div className="flex items-center">
                        <div className={`mr-2 ${trade.profit > 0 ? "text-green-500" : "text-red-500"}`}>
                          <i className={`fas fa-arrow-${trade.profit > 0 ? "up" : "down"}`}></i>
                        </div>
                        <span className="font-medium text-foreground text-base">{trade.pair}</span>
                      </div>
                      <span className={`${trade.profit > 0 ? "text-green-500" : "text-red-500"} font-medium text-lg`}>
                        {trade.profit > 0 ? "+" : ""}{trade.profit.toFixed(2)} SOL
                      </span>
                    </div>
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Buy at {trade.buyPrice} USDC</span>
                      <span>Sell at {trade.sellPrice} USDC</span>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      {formatDistanceToNow(new Date(trade.timestamp), { addSuffix: true })}
                    </div>
                  </div>
                ))}
                
                {trades.length > 3 && (
                  <Button
                    variant="outline"
                    className="w-full mt-4 py-2 px-4 bg-gray-100 hover:bg-gray-200 rounded-md text-sm font-medium text-gray-700 focus:outline-none"
                  >
                    View All Trades
                  </Button>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentTrades;
