import React from "react";

const HeroSection: React.FC = () => {
  return (
    <div className="mb-12 text-center">
      <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
        Your Trading Psychology Analysis
      </h2>
      <p className="text-muted-foreground max-w-3xl mx-auto">
        Connect your wallet to analyze your recent trading patterns. Our AI therapist will provide insights on your trading behavior and suggest improvements.
      </p>
    </div>
  );
};

export default HeroSection;
