import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ResultsSectionProps {
  isAnalyzing: boolean;
  analysisResult: any;
  error: string | null;
  onRetry: () => void;
}

const ResultsSection: React.FC<ResultsSectionProps> = ({
  isAnalyzing,
  analysisResult,
  error,
  onRetry,
}) => {
  return (
    <Card className="shadow-xl mb-6 fade-in border-2 border-primary/40">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-2xl font-semibold text-card-foreground">Your Trading Therapy Results</h3>
          <span className="text-xs text-muted-foreground" id="analysis-time">Just now</span>
        </div>
        
        {/* Loading State */}
        {isAnalyzing && (
          <div className="py-12 flex flex-col items-center justify-center">
            <div className="text-primary mb-4">
              <i className="fas fa-circle-notch fa-spin text-5xl"></i>
            </div>
            <p className="text-center text-lg">Analyzing your trading patterns...</p>
            <p className="text-center text-sm mt-2 text-muted-foreground">This might take a moment</p>
          </div>
        )}
        
        {/* Results Content */}
        {!isAnalyzing && !error && analysisResult && (
          <div className="fade-in">
            {/* Trading Summary Section */}
            <div className="mb-6 p-4 bg-primary/10 rounded-lg">
              <h4 className="font-medium text-primary-foreground text-xl mb-2">Trading Summary</h4>
              <div className="text-card-foreground">
                <p>{analysisResult.summary}</p>
              </div>
            </div>
            
            {/* Therapy Analysis Section */}
            <div className="mb-6">
              <h4 className="font-medium text-card-foreground text-xl mb-3">AI Therapy Analysis</h4>
              <div className="prose prose-invert max-w-none">
                {analysisResult.analysis.map((paragraph: string, i: number) => (
                  <p key={i} className="mb-4 text-card-foreground">{paragraph}</p>
                ))}
                
                <h5 className="font-medium mt-4 text-lg text-card-foreground">Recommendations:</h5>
                <ul className="text-card-foreground">
                  {analysisResult.recommendations.map((rec: string, i: number) => (
                    <li key={i} className="mb-2">{rec}</li>
                  ))}
                </ul>
              </div>
            </div>
            
            {/* Action Plan */}
            <div className="border-t border-muted pt-4">
              <h4 className="font-medium text-card-foreground text-xl mb-3">Your Action Plan</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-green-950/30 p-4 rounded-lg">
                  <h5 className="font-medium text-green-400 mb-2 text-lg">Strengths</h5>
                  <ul className="text-green-200 space-y-1">
                    {analysisResult.strengths.map((strength: string, i: number) => (
                      <li key={i}>{strength}</li>
                    ))}
                  </ul>
                </div>
                <div className="bg-red-950/30 p-4 rounded-lg">
                  <h5 className="font-medium text-red-400 mb-2 text-lg">Areas for Improvement</h5>
                  <ul className="text-red-200 space-y-1">
                    {analysisResult.improvements.map((improvement: string, i: number) => (
                      <li key={i}>{improvement}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Error State */}
        {!isAnalyzing && error && (
          <div className="py-8 fade-in">
            <div className="flex justify-center text-red-500 mb-4">
              <i className="fas fa-exclamation-circle text-4xl"></i>
            </div>
            <p className="text-center text-red-400 font-medium text-lg">Analysis failed</p>
            <p className="text-center text-muted-foreground mt-2" id="error-message">{error}</p>
            <div className="flex justify-center mt-4">
              <Button
                onClick={onRetry}
                variant="outline"
                className="px-6 py-3 text-base"
              >
                Try Again
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ResultsSection;
