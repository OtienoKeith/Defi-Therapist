import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { WalletInfo as WalletInfoType } from "@/lib/types";

interface WalletInfoProps {
  walletConnected: boolean;
  walletInfo: WalletInfoType | null;
  onConnect: () => void;
  onDisconnect: () => void;
  isLoading: boolean;
}

const WalletInfo: React.FC<WalletInfoProps> = ({
  walletConnected,
  walletInfo,
  onConnect,
  onDisconnect,
  isLoading,
}) => {
  return (
    <Card className="shadow-md">
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-4">Wallet Information</h3>
        
        {!walletConnected ? (
          <div className="py-8 text-center">
            <div className="wallet-pulse inline-flex items-center justify-center h-20 w-20 rounded-full bg-primary/20 mb-4">
              <i className="fas fa-wallet text-3xl text-primary"></i>
            </div>
            <p className="text-lg text-muted-foreground">Connect your Phantom wallet to get started</p>
            <Button 
              onClick={onConnect}
              className="mt-4 w-full"
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="flex items-center">
                  <i className="fas fa-circle-notch fa-spin mr-2"></i>
                  Connecting...
                </span>
              ) : (
                <span className="flex items-center">
                  <i className="fas fa-wallet mr-2"></i>
                  Connect Wallet
                </span>
              )}
            </Button>
          </div>
        ) : (
          <div>
            <div className="flex items-start space-x-3 mb-4">
              <div className="bg-primary/20 rounded-full p-3 flex-shrink-0">
                <i className="fas fa-wallet text-xl text-primary"></i>
              </div>
              <div>
                <div className="font-medium text-lg">Phantom Wallet</div>
                <div className="text-sm text-primary">Connected</div>
              </div>
            </div>
            
            <div className="space-y-3 mb-4">
              <div>
                <div className="text-sm text-muted-foreground mb-1">Wallet Address</div>
                <div className="bg-muted rounded p-3 text-sm font-mono overflow-x-auto text-card-foreground" id="wallet-address">
                  {walletInfo?.address || "Loading..."}
                </div>
              </div>
              
              <div>
                <div className="text-sm text-muted-foreground mb-1">SOL Balance</div>
                <div className="font-medium text-lg text-accent" id="sol-balance">
                  {walletInfo?.balance !== undefined ? `${walletInfo.balance} SOL` : "Loading..."}
                </div>
              </div>
            </div>
            
            <Button 
              onClick={onDisconnect}
              variant="outline"
              className="w-full"
            >
              Disconnect Wallet
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default WalletInfo;
