import React from "react";

interface HeaderProps {
  walletConnected: boolean;
  walletAddress?: string;
}

const Header: React.FC<HeaderProps> = ({ walletConnected, walletAddress }) => {
  return (
    <header className="bg-background border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className="bg-primary rounded-full p-2 flex items-center justify-center">
            <i className="fas fa-brain text-white text-xl"></i>
          </div>
          <h1 className="text-2xl font-bold text-foreground">DeFi Therapist</h1>
        </div>
        
        {/* Wallet Connection Status */}
        <div className="hidden sm:flex items-center space-x-2 text-sm">
          <div className={`h-2 w-2 rounded-full ${walletConnected ? "bg-green-500" : "bg-red-500"}`} 
               id="connection-indicator">
          </div>
          <span id="connection-text" className="text-muted-foreground">
            {walletConnected ? "Connected" : "Not connected"}
          </span>
          {walletConnected && walletAddress && (
            <span className="text-xs text-muted-foreground hidden md:inline-block">
              ({walletAddress.slice(0, 4)}...{walletAddress.slice(-4)})
            </span>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
