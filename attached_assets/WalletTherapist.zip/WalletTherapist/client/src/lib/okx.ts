import { TradeData } from "./types";

/**
 * Fetch trading data from the OKX DEX API
 * @param walletAddress The wallet address to fetch trades for
 * @returns Array of TradeData objects
 */
export const getTrades = async (walletAddress: string): Promise<TradeData[]> => {
  try {
    // In a real application, we would fetch data from the OKX DEX API here
    // For demonstration purposes, we're returning mock data
    const mockTrades: TradeData[] = [
      { 
        pair: 'SOL/USDC',
        buyPrice: 62.4,
        sellPrice: 68.3,
        amount: 2.5,
        profit: 0.82,
        timestamp: Date.now() - 2 * 24 * 60 * 60 * 1000,
      },
      {
        pair: 'BTC/USDC',
        buyPrice: 31420,
        sellPrice: 31320,
        amount: 0.002,
        profit: -0.14,
        timestamp: Date.now() - 3 * 24 * 60 * 60 * 1000,
      },
      {
        pair: 'ETH/USDC',
        buyPrice: 1842,
        sellPrice: 1878,
        amount: 0.05,
        profit: 0.31,
        timestamp: Date.now() - 5 * 24 * 60 * 60 * 1000,
      },
      {
        pair: 'SOL/USDC',
        buyPrice: 65.2,
        sellPrice: 63.8,
        amount: 1.8,
        profit: -0.22,
        timestamp: Date.now() - 6 * 24 * 60 * 60 * 1000,
      },
      {
        pair: 'AVAX/USDC',
        buyPrice: 22.14,
        sellPrice: 23.85,
        amount: 5.5,
        profit: 0.48,
        timestamp: Date.now() - 7 * 24 * 60 * 60 * 1000,
      }
    ];
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return mockTrades;
  } catch (error) {
    console.error("Error fetching trades:", error);
    throw error;
  }
};
