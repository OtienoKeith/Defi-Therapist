export interface WalletInfo {
  address: string;
  balance: number;
}

export interface TradeData {
  pair: string;
  buyPrice: number;
  sellPrice: number;
  amount: number;
  profit: number;
  timestamp: number;
}

export interface AnalysisResult {
  summary: string;
  analysis: string[];
  recommendations: string[];
  strengths: string[];
  improvements: string[];
}
